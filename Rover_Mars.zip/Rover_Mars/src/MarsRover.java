import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/* Jamie Champion 05/02/2024
 * This is my submission for the position of Graduate Software Engineer.  
 */
public class MarsRover {
    // List of Class 'Rover' to store all the Rovers on the Plateau.
    private static final List<Rover> rovers = new ArrayList<>();
    // Plateau (Grid) Dimensions
    private static int gridX;
    private static int gridY;
    // Cardinal Direction Array
    public static final char[] VALID_DIRECTIONS = {'N', 'E', 'S', 'W'};
    // Currently Active Rover
    public static Rover rover;

    /*
     * Method: Main [void]
     *          This method is used to execute the MarsRover Program.
     * @param args (String[])
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to MarsRover Program, by Jamie Champion");
        System.out.println("[For Help, type 'help']");
        while (true) {
            System.out.print("Instruction > ");
            String instruction = scanner.nextLine();
            if (instruction.equalsIgnoreCase("help")) {
                displayHelp();
                continue; 
            }
            // Process User Input instructions
            processInstruction(instruction, scanner);
        }
    }
    /* Method: processInstruction [void]
     *             Processes the User Input instruction and takes the appropriate actions. These
     * actions include: Plateau (Grid) Creation/Update, Rover Creation, Rover Movement, Receiving Rover Status and setting Rover to be 'Destroyed'.
     * @param instruction (String) - User Inputer Instruction
     * @param scanner (Scanner) - Used to gather further input across the program
     */
    private static void processInstruction(String instruction, Scanner scanner) {
        String[] inputArray = instruction.split(" ");
        try{
        if (inputArray.length == 2) {
            if (instruction.startsWith("Destroy {") && instruction.endsWith("}")) {
                int roverId = Integer.parseInt(instruction.substring(9, instruction.length() - 1));
                destroyRover(roverId);
            } 
            else if (instruction.startsWith("Status {") && instruction.endsWith("}")) {
                int roverId = Integer.parseInt(instruction.substring(8, instruction.length() - 1));
                displayRoverStatus(roverId);
            } 
            else if (instruction.split(" ")[0].startsWith("{") && instruction.split(" ")[0].endsWith("}")) {
                // Move an existing rover based on ID
                int roverId = Integer.parseInt(instruction.substring(1, instruction.length() - 1));
                moveExistingRover(roverId, scanner);
            } 
            else if (validateGridInput(inputArray)) 
            {
                gridX = Integer.parseInt(inputArray[0]);
                gridY = Integer.parseInt(inputArray[1]);
                System.out.println("Plateau size set to " + gridX + " x " + gridY);
            } 
            else 
            {
                System.out.println("Invalid plateau setup. Please try again.");
            }
        }
        else if (inputArray.length == 3) 
        {
            if (gridX != 0 && gridY != 0) 
            {
                rover = createRover(inputArray);
            } 
            else 
            {
                System.out.println("Invalid Rover creation - Please set up a Plateau first. ");
            }
        } 
        else if (inputArray.length == 1) 
        {
            String instructions = inputArray[0];
            if(instruction.equals("Status")){
                allRoverStatus();
            }
            else 
            {
                // Move a newly created rover
                if (rover != null) 
                {
                    moveRover(rover, instructions);

                    if (onCollision(rover)) 
                    {
                        System.out.println("Collision detected. Rovers cannot land in the same spot.");
                        //rover.resetToPrevious();
                    } 
                    else 
                    {
                        System.out.println(rover);
                    }
                } 
                else 
                {
                    System.out.println("No rover available. Please spawn a rover first.");
                }
            }
        } 
        else 
        {
            System.out.println("Invalid instruction. Please try again. [For Help, type 'help']");
        }
    } catch (NumberFormatException e) {
        System.out.println("Invalid Command - Please try again. Type 'help' for better command help.");
    } catch (Exception e) {
        System.out.println("Invalid Command - Please try again. Type 'help' for better command help.");
    }
    }
    /* Method: moveExistingRover [void]
     *             Move an existing rover, selected based on ID, to a position recieved by the User.
     * @param roverID (int) - ID of the Rover to be removed
     * @param scanner (Scanner) - Used to gather further input across the program
     */
    private static void moveExistingRover(int roverId, Scanner scanner) {
        try {
        Rover existingRover = findRoverById(roverId);
        if (existingRover != null) {
            System.out.println("Moving existing rover with ID " + roverId + ". Enter movement instructions:");
            String instructions = scanner.nextLine();
            if (instructions.equalsIgnoreCase("help")) 
            {
                displayHelp();
            }
            moveRover(existingRover, instructions);

            if (onCollision(existingRover)) {
                System.out.println("Collision detected. Rover has returned to its previous position.");
                //existingRover.resetToPrevious();
            } else {
                System.out.println("New Position: " + existingRover);
            }
        } else {
            System.out.println("Rover with ID " + roverId + " not found.");
        }
    } catch (NumberFormatException e) {
        System.out.println("Invalid Command - Please try again. Type 'help' for better command help.");
    }
    }
    /* Method: findRoverById [Rover]
     *             Finds the Rover by its ID.
     * @param roverID (int) - ID of the Rover to be selected/found.
     * @return Rover object if found, else null
     *
     */
    private static Rover findRoverById(int roverId) {
        for (Rover rover : rovers) {
            if (rover.id == roverId) {
                return rover;
            }
        }
        return null;
    }
    /* Method: createRover [Rover]
     *            Create a new rover based on the user given position. 
     * @param roverPosition (String[]) - Array containing X, Y and the Direction values for the Rover
     * @return Rover object if created successfully, else null
     */
    private static Rover createRover(String[] roverPosition) {
        try {
        int roverX = Integer.parseInt(roverPosition[0]);
        int roverY = Integer.parseInt(roverPosition[1]);
        char roverDirection = roverPosition[2].charAt(0);

        // Check if the rover's initial position is within the specified grid
        if (roverX < 0 || roverX > gridX || roverY < 0 || roverY > gridY) {
            System.out.println("Error: Rover cannot spawn beyond the specified grid. Please try again.");
            return null;
        }

        // Check if the rover's initial position overlaps with existing rovers
        for (Rover existingRover : rovers) {
            if (existingRover.x == roverX && existingRover.y == roverY) {
                System.out.println("Error: Rover cannot spawn on top of another rover. Please try again.");
                return null;
            }
        }

        // Check if the rover's direction matches NESW
        if (!isValidDirection(roverDirection)) {
            System.out.println("Error: Invalid rover direction. It must be one of the cardinal points (NESW). Please try again.");
            return null;
        }

        Rover rover = new Rover(roverX, roverY, roverDirection);
        rovers.add(rover);
        System.out.println("Rover " + rover.getRoverID() +" spawned at " + roverX + " " + roverY + " " + roverDirection);
        return rover;
    } catch (NumberFormatException e) {
        System.out.println("Invalid Command - Please try again. Type 'help' for better command help.");
        return null;
    } catch (ArrayIndexOutOfBoundsException e) {
        System.out.println("Error: Invalid format for rover position. Please provide X, Y, and D values. Type 'help' for better command help.");
        return null;
    }
    }
    /* Method: isValidDirection [Boolean]
     *             Check if the given direction is a valid cardinal direction.
     * @param direction (char) - Direction to be checked
     * @return true if the direction is valid, else false if Invalid
     */
    private static boolean isValidDirection(char direction) {
        for (char validDirection : VALID_DIRECTIONS) {
            if (direction == validDirection) {
                return true;
            }
        }
        return false;
    }
    /* Method: moveRover [void]
     *             Move the rover based on the user given instructions.
     * @param rover (Rover) - Rover object to be moved
     * @param instructions (String) - Movement instructions
     */
    private static void moveRover(Rover rover, String instructions) {
        if(rover.getStatus().equals("Deactivated")){
            System.out.println("Please select another Rover to move. Your previous Rover has been deactivated.");
        }
        else {
            try 
            {
                for (char instruction : instructions.toCharArray()) {
                    if (!collisionDetected(rover, instruction)) {
                        rover.move(instruction);
                    } 
                    else {
                        String[] prevState = rover.getPreviousState();
                        System.out.println("Collision detected. Rover has stopped at Position (" + prevState[0] +","+ prevState[1] +") facing direction " + prevState[2]); 
                        break;
                    }
                }
            } 
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: Invalid instruction format. Please provide valid movement instructions.");
            }
        }
    }
    /* Method: collisionDetected [Boolean]
     *             Check if a collision is detected based on the Rovers current position and given instruction.
     * @param rover (Rover) - Rover object to be checked for a potential collision
     * @param instruction (char) -  Movement instruction
     * @return True if collision detected, else false
     */
    private static boolean collisionDetected(Rover rover, char instruction) {
        // Simulate the new position based on the given instruction
        int newX = rover.x;
        int newY = rover.y;

        if (instruction == 'L' || instruction == 'R') {
            // Simulate Left or Right turn
        } else if (instruction == 'M') {
            // Simulate move forward
            switch (rover.direction) {
                case 'N':
                    newY++;
                    break;
                case 'E':
                    newX++;
                    break;
                case 'S':
                    newY--;
                    break;
                case 'W':
                    newX--;
                    break;
            }
        }
        else {
            System.out.println("Invalid Instruction " + instruction);
        }

        // Check for collisions with other rovers
        for (Rover existingRover : rovers) {
            if (existingRover != rover && existingRover.x == newX && existingRover.y == newY) {
                return true; // Collision detected
            }
        }
        // Check if the new position is within the specified grid
        return newX < 0 || newX > gridX || newY < 0 || newY > gridY;
    }
    /* Method: isValidDirection [Boolean]
     *         Check if a collision is detected between the new rover and existing rovers    
     * @param newRover (Rover) - New rover to check for collision
     * @return True if collision detected, else false
    */
    private static boolean onCollision(Rover newRover) {
        for (Rover existingRover : rovers) {
            if (existingRover != newRover && existingRover.x == newRover.x && existingRover.y == newRover.y) {
                return true; // Collision detected
            }
        }
        return false; // No collision
    }
    /* Method: validateGridInput [Boolean]
     *             Validate the user input for the plateau (gird) dimensions.
     * @param grid (String[]) - Array contains X and Y coordinates 
     * @return True if the input is valid, else false
     */
    private static boolean validateGridInput(String[] grid) {
        //Check Input is exactly 2 Characters (X,Y)
        if (grid.length != 2) {
            System.out.println("Error: Input must only 2 digits, an X coordinate and a Y coordinate - Please try again. ");
            return false;
        }
        //Check Input is a positive Integer value greater than 0 (Not null)
        for (String coordinate : grid) {
            try {
                int value = Integer.parseInt(coordinate);
                if (value <= 0) {
                    System.out.println("Error: Plateau size must be greater than 0 on the X and Y Coordinates - Please try again.");
                    return false; // Invalid value, not a positive number greater than 0
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Please only enter an integer value for the Plateau size - Please try again.");
                return false; // Unable to parse as an integer
            }
        }
        return true; //User Input has been validated
    }
    /* Method: destroyRover [void]
     *             Deactivate/Destroy the current Rover Object based on its ID
     * @param roverID (int) - ID of the Rover to be Destroyed
     */
    private static void destroyRover(int roverId) {
        Rover rover = findRoverById(roverId);
        if (rover != null) {
            rover.selfDestruct();
            System.out.println("Rover with ID " + roverId + " has been deactivated - Self Destruction initiated successfully.");
        } else {
            System.out.println("Rover with ID " + roverId + " not found.");
        }
    }
    /* Method: allRoverStatus [void]
     *           Display the status of all rovers that have been created
     */
    public static void allRoverStatus(){
        if(rovers.size() > 0 )
        {
        for (Rover rover : rovers) {
            System.out.println("[Rover Status]");
            System.out.println("Rover " + rover.getRoverID() + " Status: " + rover.getStatus());
        }
        }
        else {
            System.out.println("No Rovers found.");
        }
    }
    /* Method: displayRoverStatus [void]
     *             Display the status of a Specfic Rover based on the given ID
     * @param roverId (int) - ID of the chosen rover object
     */
    public static void displayRoverStatus(int roverId) {
        Rover rover = findRoverById(roverId);
        if (rover != null) {
            System.out.println("Rover " + rover.getRoverID() + " Status: " + rover.getStatus());
        } else {
            System.out.println("Rover with ID " + roverId + " not found.");
        }
    }
    
    /* Method: displayHelp [void]
     * Display help information about the program and available commands.
     */
    public static void displayHelp() {
            System.out.println("[Help Menu | Page 1/1]");
            System.out.println("[KEY]");
            System.out.println("X: Integer value representing the horizontal coordinate");
            System.out.println("Y: Integer value representing the vertical coordinate");
            System.out.println("D: Character representing the cardinal direction (N, E, S, W)");
            System.out.println("{ID}: Unique identifier for an existing Rover");
        
            System.out.println("\nINPUT ::---> NOTES");
            System.out.println("'X Y' --- Set the Plateau (Grid) bounds. X and Y must be integer values greater than 0.");
            System.out.println("'X Y D' --- Spawn a new Mars Rover at the given coordinates and facing the specified direction.");
            System.out.println("{ID} 'LML' --- Move an existing Rover with the given ID using a sequence of instructions.");
            System.out.println("'Destroy {ID}' --- Destroy an existing Rover with the given ID.");
            System.out.println("'Status {ID}' --- Get the status of an existing Rover with the given ID.");
            System.out.println("'Status' --- Get the status of all Rovers that have been scene on the Plateau.");

            System.out.println("'L', 'R', 'M' --- Rover movement commands:");
            System.out.println("    - 'L': Turn 90 degrees to the left");
            System.out.println("    - 'R': Turn 90 degrees to the right");
            System.out.println("    - 'M': Move forward one grid point in the current direction");
        
            System.out.println("\nEXAMPLES:");
            System.out.println("   '5 5' --- Set Plateau size to 5 x 5");
            System.out.println("   '1 2 N' --- Spawn a Rover at coordinates (1, 2) facing North");
            System.out.println("   '{1} LML' --- Move Rover with ID 1 using the sequence 'LML'");
            System.out.println("   '{1} Destroy' --- Destroy Rover with ID 1");
            System.out.println("   'L', 'R', 'M' --- Individual Rover movement commands");
                
    }
}
