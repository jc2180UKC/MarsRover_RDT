import java.util.Arrays;

    /* Jamie Champion 05/02/2024 
     * Each rover has a unique id, position (x, y), cardinal direction, and status (active or deactivated). 
     */
class Rover {
    
    // Static variable to assign unique IDs
    private static int nextId = 1; 
    int id;
    int x;
    int y;
    char direction;
    // Initial position and direction of the rover
    private final String[] spawnPoint;
    // Previous cardinal direction
    private char previousDirection;
    String status; //Either Active or Deactivated 

     /* Class constructor: Rover
     *             Constructs a new Rover with the given initial position and direction.
     *
     * @param x         Initial x-coordinate
     * @param y         Initial y-coordinate
     * @param direction Initial cardinal direction (N, E, S, W)
    */
    public Rover(int x, int y, char direction) {
        this.id = nextId++;
        this.x = x;
        this.y = y;
        this.direction = isValidDirection(direction) ? direction : 'N';
        spawnPoint = new String[]{String.valueOf(x), String.valueOf(y), String.valueOf(direction)};
        previousDirection = direction;
        status = "Active";
    }
    /* Method: isValidDirection [Boolean]
     *             Checks if the provided direction is valid (N, E, S, W).
     * @param direction Direction to be checked
     * @return True if the direction is valid, else false
     */
    private boolean isValidDirection(char direction) {
        for (char validDirection : MarsRover.VALID_DIRECTIONS) {
            if (direction == validDirection) {
                return true;
            }
        }
        return false;
    }
    /*
     * Method: move [void]
     *          Moves the rover based on the given instruction (L, R, M).
     * @param instruction (char) - Movement Instruction
     */
    public void move(char instruction) {
        // Save the current position as the previous position
        //previousPosition[0] = x;
        //previousPosition[1] = y;

        if (instruction == 'L') {
            turnLeft();
        } else if (instruction == 'R') {
            turnRight();
        } else if (instruction == 'M') {
            moveForward();
        }
    }
    /*
     * Method: turnLeft [void]
     *          Turns the Rover object 90 degrees to the Left. 
     */
    private void turnLeft() {
        switch (direction) {
            case 'N':
                previousDirection = 'N';
                direction = 'W';
                break;
            case 'W':
                previousDirection = 'W';
                direction = 'S';
                break;
            case 'S':
                previousDirection = 'S';
                direction = 'E';
                break;
            case 'E':
                previousDirection = 'E';
                direction = 'N';
                break;
        }
    }
    /*
     * Method: turnRight [void]
     *          Turns the Rover object 90 degrees to the Right. 
     */
    private void turnRight() {
        switch (direction) {
            case 'N':
                previousDirection = 'N';
                direction = 'E';
                break;
            case 'E':
                previousDirection = 'E';
                direction = 'S';
                break;
            case 'S':
                previousDirection = 'S';
                direction = 'W';
                break;
            case 'W':
                previousDirection = 'W';
                direction = 'N';
                break;
        }
    }
    /*
     * Method: moveForward [void]
     *          Moves the rover one grid point forward in the current direction. 
    */
    private void moveForward() {
        switch (direction) {
            case 'N':
                y++;
                break;
            case 'E':
                x++;
                break;
            case 'S':
                y--;
                break;
            case 'W':
                x--;
                break;
        }
    }
    /*
     * Method: toString [String]
     *          Returns a String representation of the Rover object
     * @returns a String representation of the rover.
    */
    @Override
    public String toString() {
        return "Rover " + id + " | ("+ x + ", " + y +") |  Direction: " + direction;
    }
    /*
     * Method: getRoverID [int]
     *          Returns a unique rover ID
     * @returns RoverID
    */
    public int getRoverID(){
        return id;
    }
    /*
     * Method: getStatus [String]
     *          Returns the status of the Rover
     * @returns Rover Status
    */
    public String getStatus() {
        return status;
    }
    /*
     * Method: selfDestruct [void]
     *          Deactives the Rover.
    */
    public void selfDestruct(){
        status = "Deactivated";
    }
    /*
     * Method: getPreviousState [String[]]
     *         Returns an array containing the previous state of the rover (x, y, previousDirection).
     * @returns an Array of Previous State info
    */
    public String[] getPreviousState(){
        String[] state = {x + "", y+ "" , previousDirection + ""};
        return state;
    }
}
